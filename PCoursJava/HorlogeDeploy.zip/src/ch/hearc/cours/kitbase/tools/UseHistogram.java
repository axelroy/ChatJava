
package ch.hearc.cours.kitbase.tools;

import java.util.Arrays;

public class UseHistogram
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		int nbFaces = 6;
		int nbLances = Integer.MAX_VALUE;
		String fileName = "test.xls";
		int[] tabHisto = Histogram.generateHistogram(nbFaces, nbLances);
		System.out.println(Arrays.toString(tabHisto));
		Histogram.generateSpreadsheet(tabHisto, nbLances, fileName);
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
