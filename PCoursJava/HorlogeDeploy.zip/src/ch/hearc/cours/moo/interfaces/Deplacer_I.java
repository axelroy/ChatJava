
package ch.hearc.cours.moo.interfaces;

public interface Deplacer_I
	{

	public void courir();

	public void marcher();
	}
