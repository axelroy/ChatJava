
package ch.hearc.cours.gui.jcomponent.hello.hello2;



public class UseJFrameHello2
	{
/*------------------------------------------------------------------*\
|*							Methodes Public							*|
\*------------------------------------------------------------------*/

public static void main(String[] args)
	{
	main();
	}

public static void main()
	{
	new JFrameHello2();
	}

/*------------------------------------------------------------------*\
|*							Methodes Private						*|
\*------------------------------------------------------------------*/
	}

