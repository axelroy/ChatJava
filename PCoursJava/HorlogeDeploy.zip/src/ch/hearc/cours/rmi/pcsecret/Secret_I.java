
package ch.hearc.cours.rmi.pcsecret;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Secret_I extends Remote
	{

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public MessageSecret getMessage() throws RemoteException;
	}
