
package ch.hearc.cours.moo.interfaces;

public interface Manger_I
	{

	public void manger();
	}
