
package ch.hearc.cours.gui.java2d.images.tools;

import javax.swing.ImageIcon;
/**
 * Permet de checker que les images sont loader par la classe magasin
 */
public class UseMagasin
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		@SuppressWarnings("unused")
		ImageIcon coffee = MagasinImage.coffee;
		//ImageIcon warning = MagasinImage.warning;
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
