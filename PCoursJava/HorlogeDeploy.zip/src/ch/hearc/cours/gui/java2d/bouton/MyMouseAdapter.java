
package ch.hearc.cours.gui.java2d.bouton;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MyMouseAdapter implements MouseListener
	{

	/*------------------------------------------------------------------*\
	|*							Constructeurs							*|
	\*------------------------------------------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/
	@Override
	public void mouseClicked(MouseEvent e)
		{

		}

	@Override
	public void mouseEntered(MouseEvent e)
		{

		}

	@Override
	public void mouseExited(MouseEvent e)
		{

		}

	@Override
	public void mousePressed(MouseEvent e)
		{

		}

	@Override
	public void mouseReleased(MouseEvent e)
		{

		}

	/*------------------------------*\
	|*				Set				*|
	\*------------------------------*/

	/*------------------------------*\
	|*				Get				*|
	\*------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Attributs Private						*|
	\*------------------------------------------------------------------*/
	}
