
package ch.hearc.cours.kitbase.junit.hello;

public class Calculatrice
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static int add(int a, int b)
		{
		return a + b;
		}

	public static int multiply(int a, int b)
		{
		return a * b;
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
