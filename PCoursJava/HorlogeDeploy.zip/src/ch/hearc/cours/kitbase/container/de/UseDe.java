
package ch.hearc.cours.kitbase.container.de;

public class UseDe
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		int nbFaces=6;
		int nbExp=Integer.MAX_VALUE;
		int moyenne = De.moyenneur(nbFaces,nbExp);
		System.out.println("moyenne : " + moyenne);
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
