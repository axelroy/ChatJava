
package ch.hearc.cours.moo.interfaces;

public interface Vivre_I extends Deplacer_I ,Manger_I
	{

	public void respirer();
	}
