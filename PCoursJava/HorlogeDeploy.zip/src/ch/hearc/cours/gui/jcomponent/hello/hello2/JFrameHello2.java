
package ch.hearc.cours.gui.jcomponent.hello.hello2;

import javax.swing.JFrame;

public class JFrameHello2 extends JFrame
	{

	/*------------------------------------------------------------------*\
	|*							Constructeurs							*|
	\*------------------------------------------------------------------*/

	public JFrameHello2()
		{
		controle();
		geometrie();
		apparence();

		}

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	/*------------------------------*\
	|*				Set				*|
	\*------------------------------*/

	/*------------------------------*\
	|*				Get				*|
	\*------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	private void apparence()
		{
		setSize(360, 220);
		setLocationRelativeTo(null);//Centre automatiquement la fen�tre
		setVisible(true);
		}

	private void geometrie()
		{
		panelHello2 = new JPanelHello2();
		this.add(panelHello2);
		}

	private void controle()
		{
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		}

	/*------------------------------------------------------------------*\
	|*							Attributs Private						*|
	\*------------------------------------------------------------------*/

	//TOOLS
	private JPanelHello2 panelHello2;

	}
