
package ch.hearc.cours.moo.doublerepresentation;

public class UseComplex
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		Complex z1 = Complex.createCartesian(1, 1);
		System.out.println(z1);
		}
	}
