
package ch.hearc.cours.gui.layout.combinaison.hello;



public class UseJFrameCombinaisonHello
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		new JFrameCombinaisonHello();
		}

/*------------------------------------------------------------------*\
|*							Methodes Private						*|
\*------------------------------------------------------------------*/

	}

