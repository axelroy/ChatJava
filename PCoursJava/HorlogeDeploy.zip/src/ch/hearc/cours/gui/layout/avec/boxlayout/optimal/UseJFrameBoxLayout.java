
package ch.hearc.cours.gui.layout.avec.boxlayout.optimal;



public class UseJFrameBoxLayout
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		new JFrameBoxLayout();
		}

/*------------------------------------------------------------------*\
|*							Methodes Private						*|
\*------------------------------------------------------------------*/

	}

