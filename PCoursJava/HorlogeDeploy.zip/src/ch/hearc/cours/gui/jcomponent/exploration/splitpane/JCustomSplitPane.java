
package ch.hearc.cours.gui.jcomponent.exploration.splitpane;

import javax.swing.JLabel;
import javax.swing.JSplitPane;

public class JCustomSplitPane extends JSplitPane
	{

	/*------------------------------------------------------------------*\
	|*							Constructeurs							*|
	\*------------------------------------------------------------------*/

	public JCustomSplitPane()
		{
		super(JSplitPane.HORIZONTAL_SPLIT);
		setDividerLocation(200);
		setOneTouchExpandable(true);

		labelhaut = new JLabel("Haut");
		labelbas = new JLabel("Bas");

		setLeftComponent(labelhaut);
		setRightComponent(labelbas);
		}
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	/*------------------------------*\
	|*				Set				*|
	\*------------------------------*/

	/*------------------------------*\
	|*				Get				*|
	\*------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Attributs Private						*|
	\*------------------------------------------------------------------*/
	private JLabel labelhaut;
	private JLabel labelbas;

	}
