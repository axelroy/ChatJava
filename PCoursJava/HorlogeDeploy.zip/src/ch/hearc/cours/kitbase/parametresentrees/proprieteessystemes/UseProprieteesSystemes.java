
package ch.hearc.cours.kitbase.parametresentrees.proprieteessystemes;

public class UseProprieteesSystemes
	{

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		String user = System.getProperty("user.name");
		System.out.println(user);
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
