
package ch.hearc.cours.moo.thread.addVector;

import java.util.Arrays;

public class UseAddVector
	{

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		double[] v1 = {10,20,30,40,50,60};
		double[] v2 = {100,200,300,400,500,600};
		AddVector add = new AddVector(v1, v2);
		add.run();
		System.out.println(Arrays.toString(add.getW()));
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}

