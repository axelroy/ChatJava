
package ch.hearc.cours.gui.layout.sans.hello;

import javax.swing.JButton;
import javax.swing.JPanel;

public class JPanelWithoutLayout extends JPanel
	{

	/*------------------------------------------------------------------*\
	|*							Constructeurs							*|
	\*------------------------------------------------------------------*/

	public JPanelWithoutLayout()
		{
		geometrie();
		controle();
		apparence();
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	/*------------------------------*\
	|*				Set				*|
	\*------------------------------*/

	/*------------------------------*\
	|*				Get				*|
	\*------------------------------*/

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	private void apparence()
		{
		//RIEN
		}

	private void controle()
		{
		//RIEN
		}

	private void geometrie()
		{
		bouton = new JButton("cercle");
		bouton.setSize(100, 50);
		bouton.setLocation(20, 20);
		setLayout(null);
		add(bouton);
		}

	/*------------------------------------------------------------------*\
	|*							Attributs Private						*|
	\*------------------------------------------------------------------*/

	//TOOLS
	private JButton bouton;

	}
