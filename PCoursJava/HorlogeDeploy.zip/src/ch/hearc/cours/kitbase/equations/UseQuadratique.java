
package ch.hearc.cours.kitbase.equations;

public class UseQuadratique
	{
	/*------------------------------------------------------------------*\
	|*							Methodes Public							*|
	\*------------------------------------------------------------------*/

	public static void main(String[] args)
		{
		main();
		}

	public static void main()
		{
		double[] tabCoefficient = Quadratique.saisir();
		double[] tabX = Quadratique.solve(tabCoefficient);
		Quadratique.print(tabCoefficient, tabX);
		}

	/*------------------------------------------------------------------*\
	|*							Methodes Private						*|
	\*------------------------------------------------------------------*/

	}
